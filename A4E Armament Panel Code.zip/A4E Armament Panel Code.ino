#define DCSBIOS_IRQ_SERIAL
#include <DcsBios.h>

DcsBios::Switch2Pos ARM_STATION1("ARM_STATION1", 6);
DcsBios::Switch2Pos ARM_STATION2("ARM_STATION2", 7);
DcsBios::Switch2Pos ARM_STATION3("ARM_STATION3", 9);
DcsBios::Switch2Pos ARM_STATION4("ARM_STATION4", 11);
DcsBios::Switch2Pos ARM_STATION5("ARM_STATION5", 13);
DcsBios::Switch2Pos ARM_MASTER("ARM_MASTER", 12);
DcsBios::Switch2Pos ARM_GUN("ARM_GUN", 3);
DcsBios::Switch3Pos ARM_BOMB("ARM_BOMB", 5, 4);

const int POT_PIN2 = A2;
const int POT_PIN = A0;
// Track the current and previous switch position (0 to 6)
int currentPosition = -1;
int lastPosition = -1;

int currentPosition2 = -1;
int lastPosition2 = -1;


void setup() {
DcsBios::setup();
 pinMode(POT_PIN, INPUT);
 pinMode(POT_PIN2, INPUT);
}

void loop() {
DcsBios::loop();
int rawValue = analogRead(POT_PIN);

  // Divide 0-1023 into 7 optimized segments (~146 units each)
  if (rawValue < 146) {
    currentPosition = 0; // State 0
  } else if (rawValue >= 146 && rawValue < 292) {
    currentPosition = 1; // State 1
  } else if (rawValue >= 292 && rawValue < 438) {
    currentPosition = 2; // State 2
  } else if (rawValue >= 438 && rawValue < 584) {
    currentPosition = 3; // State 3
  } else if (rawValue >= 584 && rawValue < 730) {
    currentPosition = 4; // State 4
  } else if (rawValue >= 730 && rawValue < 876) {
    currentPosition = 5; // State 5
  } else {
    currentPosition = 6; // State 6
  }

  // Only send data if the position physically changes
  if (currentPosition != lastPosition) {
    
    // The exact DCS-BIOS identifier for the A-4E Emergency Release Selector
    sendDcsBiosMessage("ARM_EMERG_SEL", String(currentPosition).c_str());
    
    lastPosition = currentPosition;
  }
  
  delay(40);
  int rawValue2 = analogRead(POT_PIN2);

  // Divide 0-1023 into 7 optimized segments (~146 units each)
  if (rawValue2 < 146) {
    currentPosition2 = 4; // State 0
  } else if (rawValue2 >= 146 && rawValue2 < 292) {
    currentPosition2 = 5; // State 1
  } else if (rawValue2 >= 292 && rawValue2 < 438) {
    currentPosition2 = 6; // State 2
  } else if (rawValue2 >= 438 && rawValue2 < 584) {
    currentPosition2 = 0; // State 3
  } else if (rawValue2 >= 584 && rawValue2 < 730) {
    currentPosition2 = 1; // State 4
  } else if (rawValue2 >= 730 && rawValue2 < 876) {
    currentPosition2 = 2; // State 5
  } else {
    currentPosition2 = 3; // State 6
  }

  // Only send data if the position physically changes
  if (currentPosition2 != lastPosition2) {
    
    // The exact DCS-BIOS identifier for the A-4E Emergency Release Selector
    sendDcsBiosMessage("ARM_FUNC_SEL", String(currentPosition2).c_str());
    
    lastPosition2 = currentPosition2;
  }
  
  delay(40);
}
